create table patients
(
    patient_id number(4),
    patient_name  varchar2(24),
    patient_email  varchar2(24),
    registered_date date
    )
    
    
    alter table patients
    add constraint pk_patientId primary key(patient_id)
   
    alter table patients 
    modify (patient_name not null)
    
    alter table patients 
    modify (patient_email unique)
    
    
    insert into patients values (1, 'Hari Puttar', 'hp@abc.com', sysdate)
    insert into patients values (2, 'VKS', 'vks@abc.com', sysdate)
    insert into patients values (3, 'Yash', 'rocky@abc.com', sysdate)
    
 
 
    
    
create table medicines
(
    medicine_id number(4),
    medicine_name  varchar2(24)
    )
    alter table medicines
    add constraint pk_medicineId primary key(medicine_id)
    
    alter table medicines
    modify (medicine_name not null)
    
    insert into medicines values (1, 'Flexon')
    insert into medicines values (2, 'Crocin')
    insert into medicines values (3, 'Sprot')
    insert into medicines values (4, 'Azithromycin')
    insert into medicines values (5, 'Pantop')
    
    select * from medicines
    
create table prescriptions
(
    prescription_id number(4),
    prescribed_date  date,
    patient_id  varchar2(24)
    )
     
    
    insert into prescriptions values (1, sysdate, 1)
    insert into prescriptions values (2, sysdate+1, 2)
    insert into prescriptions values (3, sysdate-1, 3)
    
    
    alter table prescriptions
    add constraint fk_patientId
    foreign key(patient_id)
    references patients(patient_id)
 
create table info
(
    id number(4),
    prescription_id number(4),
    medicine_id number(4) 
    ) 
    alter table info
    add constraint pk_infoId primary key(id)
    
 alter table info
 add constraint fk_prescriptionId
 foreign key(prescription_id)
 references prescriptions(prescription_id)
 
 alter table info
 add constraint fk_medicineId
 foreign key(medicine_id)
 references medicines(medicine_id)   

select patient_id, patient_name, patient_email from patients
where registered_date BETWEEN sysdate AND sysdate+2 


select i.prescription_id, p.patient_id, p.prescribed_date, m.medicine_name, a.patient_name
from info i, prescriptions p, medicines m, patients a
where i.prescription_id = p.prescription_id and i.medicine_id = m.medicine_id and p.patient_id=a.patient_id and a.patient_name='VKS'
    